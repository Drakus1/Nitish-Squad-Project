/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sam
 */

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.regex.Pattern;

import java.net.ServerSocket;
import java.util.ArrayList;

import javax.swing.DefaultListModel;



public class ServerCommunication {
    
    public static final int sigDigits = 4;
    
    private int port;
    private ArrayList<Dictionary> myLibrary;
    private DefaultListModel<String> listModel;
    private ServerSocket ss;
    private Socket client;
    private ObjectOutputStream outputStream;
    private ObjectInputStream inputStream;
    private String clientChoice;
    private ArrayList<Double> products;
    
    private boolean connected;
    
    static {
        System.load("/Users/sam/NetBeansProjects/serverGMP/dist/serverGMP.dylib");
    }
    
    private native String GMPexponent(String ciphertext, int power, String nSquared);
    private native String GMPproduct(String ciphertext1, String ciphertext2, String nSquared);
    
    public ServerCommunication(int port, ArrayList<Dictionary> myLibrary, 
            DefaultListModel<String> listModel) throws IOException {
        
        this.port = port;
        this.myLibrary = myLibrary;
        this.listModel = listModel;
        
        // open server socket, connect to client socket
        this.ss = new ServerSocket(port); 
        this.client = ss.accept();
        
        // set up input and output streams
        this.outputStream = new ObjectOutputStream(client.getOutputStream());
        this.inputStream = new ObjectInputStream(client.getInputStream());
        
        this.connected = true;
        
        // sends collection choices to client
        this.outputStream.writeObject(this.listModel);
    }
    
    public void communicate() throws Exception {
        try {
            
            // gets client's collection choice
            this.clientChoice = (String) inputStream.readObject();

            // determines which dictionary to send to client
            int index = this.listModel.indexOf(this.clientChoice);
            Dictionary selectedDictionary = this.myLibrary.get(index);
            ArrayList<String> myWords = selectedDictionary.getAllWords();

            // sends client unique words in selected collection
            this.outputStream.writeObject(myWords);

            // gets encrypted vector and n^2 from client
            String[] sVector = (String[])this.inputStream.readObject();
            String nSquared = (String) this.inputStream.readObject();
            
            // fills ewith encrypted dot products with each record in server
            ArrayList<String> encryptedProducts = 
                    homomorphic(sVector, selectedDictionary, nSquared);
            
            // gives encrypted dot products to client
            this.outputStream.writeObject(encryptedProducts);

            // close server
            // closeServer();
            return;
            
        } catch (Exception e) {
            this.connected = false;
            closeServer();
            return;
        }
    }
    
    public ArrayList<Double> getProducts() {
        return this.products;
    }
    
    public boolean isConnected() {
        return this.connected;
    }
    
    private ArrayList<String> homomorphic(String[] sVector, Dictionary selectedDictionary,
            String nSquared) {
        
        ArrayList<String[]> intermediateProducts = new ArrayList<String[]>();
        ArrayList<String> encryptedProducts = new ArrayList<String>();
        
        // gets server vectors and normalizes them
        Vector[] serverVectors = selectedDictionary.getVectorArray();
        for (int i = 0; i < serverVectors.length; i++)
            serverVectors[i].normalize();
        
        // gets int vector
        ArrayList<int[]> convertedVectors = convert(serverVectors);
        
        // multiplicative homomorphic
        // for each server integer vector...
        for (int i = 0; i < convertedVectors.size(); i++) {
            int[] iVector = convertedVectors.get(i);
            
            String[] curProduct = new String[iVector.length];
            
            for (int j = 0; j < iVector.length; j++) {
                curProduct[j] = GMPexponent(sVector[j], iVector[j], nSquared);
                
            }
            intermediateProducts.add(curProduct);
        }
        
        
        // additive homomorphic
        
        // intermediate products has multiplicative homomorphic properties applied
        // for each server vector
        for (int i = 0; i < intermediateProducts.size(); i++) {
            
            String[] singleIntermediate = intermediateProducts.get(i);
            String cumulativeProduct = singleIntermediate[0];
            
            for (int j = 1; j < singleIntermediate.length; j++) {
                cumulativeProduct = GMPproduct(singleIntermediate[j], cumulativeProduct, nSquared);
            }
            encryptedProducts.add(cumulativeProduct); 
        }
        
        return encryptedProducts;
    }
    
    private ArrayList<int[]> convert(Vector[] serverVectors) {
        
        Conversions myConversions = new Conversions(sigDigits);
        ArrayList<int[]> convertedVectors = new ArrayList<int[]>();
        
        for (int i = 0; i < serverVectors.length; i++) {
            int[] iVector = myConversions.wholeNumberVector(serverVectors[i]);
            convertedVectors.add(iVector);
        }
        return convertedVectors;
    }
    
    public void closeServer() throws Exception{
        this.inputStream.close();
        this.outputStream.close();
        this.client.close();
        this.ss.close();
    }
}
