/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sam
 */


import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.TermFreqVector;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.TermDocs;
import org.apache.lucene.index.TermEnum;
import org.apache.lucene.index.Term;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.io.FileReader;
import java.util.HashSet;
import javax.swing.DefaultListModel;

public class ClientCommunication {
    
    private static final int positionNSQUARED = 2;
    
    private static final int sigDigits = 4;
    private static final int numBits = 512;
    
    private static Conversions myConversions;
    
    private String server;
    private int port;
    private String dataDir;
    private String indexDir;
    
    private Socket socket;
    private ObjectOutputStream outputStream;
    private ObjectInputStream inputStream;
    private DefaultListModel<String> listModel;
    private ArrayList<Double> products;
    
    static {
        System.load("/Users/sam/NetBeansProjects/myGMP/dist/myGMP.dylib");
    }
    
    private native String[] initialize(int numBits);
    private native String encrypt(int message, String[] pk);
    private native int decrypt(String ciphertext, String[] pk);
    

    public ClientCommunication(String server, int port) throws Exception {
        this.server = server;
        this.port = port;
        
        // attempts to connect to server
        this.socket = new Socket(server, port);
        this.outputStream = new ObjectOutputStream(socket.getOutputStream());
        this.inputStream = new ObjectInputStream(socket.getInputStream());
        
        // receives options list from server
        this.listModel = (DefaultListModel<String>) inputStream.readObject();
        // initialize Conversions object
        myConversions = new Conversions(sigDigits);
        return;
    }
    
    public DefaultListModel<String> getListModel() {
        return this.listModel;
    }
    
    public ArrayList<Double> getProducts() {
        return this.products;
    }
    
    public void communicate(String selection, String indexDir, 
            String dataDir) throws Exception{
        
        this.indexDir = indexDir;
        this.dataDir = dataDir;
        
        // tells server which collection was selected
        this.outputStream.writeObject(selection);
        
        // receives unique words of selected collection
        ArrayList<String> uniqueWords = (ArrayList<String>) this.inputStream.readObject();
        
        // creates and normalizes vector from unique word dictionary
        Vector myVector = LuceneIndex(uniqueWords);
        myVector.normalize();
        
        // create private key
        String[] pk = initialize(numBits);
        
        // encrypts query Vector
        String[] sVector = encryptVector(myVector, pk);
        
        // sends encrypted string vector to server
        this.outputStream.writeObject(sVector);
        
        // sends n^2 to server
        String nSquared = pk[positionNSQUARED];
        this.outputStream.writeObject(nSquared);
        
        // receives ArrayList of encrypted dot products in String form
        ArrayList<String> encryptedProducts = (ArrayList<String>) this.inputStream.readObject();
        
        // decrypts encrypted dot products, scales them to [0,1]
        ArrayList<Double> decryptedProducts = new ArrayList<Double>();
        for (int i = 0; i < encryptedProducts.size(); i++) {
            String cipherProduct = encryptedProducts.get(i);
            
            int decryptedDot = decrypt(cipherProduct, pk);
            
            double scaledDot = myConversions.scaledDotProduct(decryptedDot);
            decryptedProducts.add(scaledDot);
           
        }
        
        this.products = decryptedProducts;
        
        // closeClient();
        return;
    }
    
    
    private Vector LuceneIndex(ArrayList<String> uniqueWords) throws Exception{
        Indexer indexer = new Indexer(indexDir);
        int numIndexed;
        Vector queryVector = new Vector(uniqueWords.size());
        try {
            numIndexed = indexer.index(dataDir, new TextFilesFilter());
            IndexReader reader = indexer.getWriter().getReader();
            int numDocuments = reader.numDocs();
            
            
            // create vector;
            TermFreqVector freqVector = reader.getTermFreqVector(0, "contents");
            int[] termFreqs = freqVector.getTermFrequencies();
            int position = 0;
            int frequency = 0;
            
            for (String term : uniqueWords) {
                int index = freqVector.indexOf(term);
                if (index == -1)
                    queryVector.setValue(position, 0);
                else {
                    frequency = termFreqs[index];
                    queryVector.setValue(position, frequency);
                }
                position++;
                
            }
            reader.close();
            
        } finally {
            indexer.close();
        }
        return queryVector;
    }
        
    private String[] encryptVector(Vector myVector, String[] pk) {
        
        // gets whole number components of Vectors, according to myConversions
        int[] iVector = myConversions.wholeNumberVector(myVector);
              
        // creates encrypted vector of strings from iVector
        String[] sVector = new String[myVector.getDimension()];
        for (int i = 0; i < myVector.getDimension(); i++) {
            sVector[i] = encrypt(iVector[i], pk);
        }
        
        return sVector;
    }
    
    public void closeClient() throws Exception{
        inputStream.close();
        outputStream.close();
        socket.close();
    }
    
    
    private static class TextFilesFilter implements FileFilter {
    	public boolean accept(File path) {
      	return path.getName().toLowerCase()        
             .endsWith(".txt");                  
        }
    }
}
