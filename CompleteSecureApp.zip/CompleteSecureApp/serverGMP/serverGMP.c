/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include"serverGMP.h"
#include <stdio.h>
#include <stdlib.h>
#include <gmp.h>

static const int BASE = 10;

JNIEXPORT jstring JNICALL Java_ServerCommunication_GMPexponent
  (JNIEnv *env, jobject obj, jstring ciphertext, jint exponent, jstring nSquared) {
    
    // convert java strings to c strings
    const char *cipherString = (*env)->GetStringUTFChars(env, ciphertext, NULL);
    if (cipherString == NULL) return NULL;
    const char *nSquaredString = (*env)->GetStringUTFChars(env, nSquared, NULL);
    if (nSquaredString == NULL) return NULL;
    
    mpz_t cipherNum, modulus;
    mpz_inits(cipherNum, modulus, NULL);
    
    // set mpz_t variables from strings
    int success1, success2;
    success1 = mpz_set_str(cipherNum, cipherString, BASE);
    success2 = mpz_set_str(modulus, nSquaredString, BASE);
    if (success1 == -1 || success2 == -1)
        printf("Failed to convert string to number\n");
    
    // release resources
    (*env)->ReleaseStringUTFChars(env, ciphertext, cipherString);
    (*env)->ReleaseStringUTFChars(env, nSquared, nSquaredString);
    
    // computes exponent
    mpz_powm_ui(cipherNum, cipherNum, exponent, modulus);
    // converts mpz_t to c string, then to java string
    const char *exponentStringC = mpz_get_str(NULL, 10, cipherNum);
    jstring exponentStringJava = (*env)->NewStringUTF(env, exponentStringC);
    
    // free memory
    free(exponentStringC);
    mpz_clears(cipherNum, modulus, NULL);
    
    return exponentStringJava;
}
        
JNIEXPORT jstring JNICALL Java_ServerCommunication_GMPproduct
  (JNIEnv *env, jobject obj, jstring ciphertext1, jstring ciphertext2, jstring nSquared) {
    
    // converts parameters to c strings
    const char *cipherString1 = (*env)->GetStringUTFChars(env, ciphertext1, NULL);
    if (cipherString1 == NULL) return NULL;
    const char *cipherString2 = (*env)->GetStringUTFChars(env, ciphertext2, NULL);
    if (cipherString2 == NULL) return NULL;
    const char *nSquaredString = (*env)->GetStringUTFChars(env, nSquared, NULL);
    if (nSquaredString == NULL) return NULL;
    
    // initializes gmp variables
    mpz_t cipherNum1, cipherNum2, result, modulus;
    mpz_inits(cipherNum1, cipherNum2, result, modulus, NULL);
    
    // converts c strings to gmp numbers
    int success1, success2, success3;
    success1 = mpz_set_str(cipherNum1, cipherString1, BASE);
    success2 = mpz_set_str(cipherNum2, cipherString2, BASE);
    success3 = mpz_set_str(modulus, nSquaredString, BASE);
    if (success1 == -1 || success2 == -1 || success3 == -1)
        fprintf(stderr, "Failed to convert string to number\n");
    
    // multiply two ciphertexts together, modulo n^2
    mpz_mul(result, cipherNum1, cipherNum2);
    mpz_mod(result, result, modulus);
    
    // release resources
    (*env)->ReleaseStringUTFChars(env, ciphertext1, cipherString1);
    (*env)->ReleaseStringUTFChars(env, ciphertext2, cipherString2);
    (*env)->ReleaseStringUTFChars(env, nSquared, nSquaredString);
    
    // converts result to c string
    const char *productStringC = mpz_get_str(NULL, 10, result);
    jstring productStringJava = (*env)->NewStringUTF(env, productStringC);
    
    // free memory
    free(productStringC);
    mpz_clears(cipherNum1, cipherNum2, result, modulus, NULL);
    
    // return string to java
    return productStringJava;
}